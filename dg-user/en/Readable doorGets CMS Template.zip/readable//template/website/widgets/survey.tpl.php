<?php if (!defined(DOORGETS)) { header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 7.0 - 31, August 2015
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2015 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/t/en/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


 /*
  * Variables :
  * 
        $content
 */
        $labelModuleGroup   = $this->getActiveModules();

        $urlAfterAction     = urlencode(PROTOCOL.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
        $urlEdition         = URL_USER.$this->_lgUrl.'?controller=modulesurvey&uri='.$isBlock['uri'].'&lg='.$this->getLangueTradution().'&back='.$urlAfterAction;
    
?>
<!-- doorGets:start:widgets/survey -->
<div class="survey-static survey-static-[{!$uri_module!}]">
    [{?($this->isUser && in_array($Module['id'],$this->_User['liste_widget'])):}]
    <div class="btn-group btn-front-edit-[{!$uri_module!}] navbar-right pull-right z-max-index">
        <a class="btn btn-default dropdown-toggle" data-toggle="dropdown" href="#">
            <b  class="glyphicon glyphicon-cog"></b> [{!$this->__('Action')!}]
            <span class="caret"></span>
        </a>
        <ul class="dropdown-menu">
            <li><a href="[{!$urlEdition!}]" class="navbut"><b class="glyphicon glyphicon-pencil"></b> [{!$this->__('Modifier le sondage')!}]</a></li>
        </ul>
    </div>
    [?]
    [{!$survey['question']!}]
    <ul>
        [{?(!empty($survey['response_a'])):!}]<li>[{!$survey['response_a']!}]</li>[?]
        [{?(!empty($survey['response_b'])):!}]<li>[{!$survey['response_b']!}]</li>[?]
        [{?(!empty($survey['response_c'])):!}]<li>[{!$survey['response_c']!}]</li>[?]
        [{?(!empty($survey['response_d'])):!}]<li>[{!$survey['response_d']!}]</li>[?]
        [{?(!empty($survey['response_e'])):!}]<li>[{!$survey['response_e']!}]</li>[?]
        [{?(!empty($survey['response_f'])):!}]<li>[{!$survey['response_f']!}]</li>[?]
        [{?(!empty($survey['response_g'])):!}]<li>[{!$survey['response_g']!}]</li>[?]
        [{?(!empty($survey['response_h'])):!}]<li>[{!$survey['response_h']!}]</li>[?]
        [{?(!empty($survey['response_i'])):!}]<li>[{!$survey['response_i']!}]</li>[?]
    </ul>
    
</div>
<!-- doorGets:end:widgets/survey -->
