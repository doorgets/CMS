
$('.magnificpopup-parent-container').magnificPopup({
    delegate: 'a',
    type: 'image',
    gallery: {
        enabled:true
    }
});



$('.btn-form-send input').on('click',function(event){

    event.preventDefault();
    var data = new FormData();
    var idForm = $(this).attr('id');
    var id = idForm.replace('_submit','');
    var current = $(this);
    var currentHtml = current.html();
    current.html('<i class="fa fa-spinner fa-spin"></i>');
    $.ajax({
        url: BASE_URL + 'ajax/?controller=form&action=sendForm&lg='+LG_CURRENT+'&uri='+id,
        type: 'POST',
        data: $("#"+id).serialize(),
        success: function(response, textStatus, jqXHR) {
            var rep = JSON.parse(response);
            current.attr("disabled", "disabled");
            if (rep.code == '200') {
                $('#'+id).append('<div class="alert alert-success text-center">'+rep.data+'</div>');
                window.setTimeout(function(){
                    location.reload();
                },3000);
            } else {
                $.each(rep.data,function(k,v){
                    $('#'+id + ' #'+k).addClass('i-error');
                    if (k == 'result_captcha') {
                        $('#'+id + ' #captcha_result').addClass('i-error');
                    }
                });
                current.removeAttr("disabled");
            }

            $('.i-error').on('click focus',function(){
                $(this).removeClass('i-error');
            });
            current.html(currentHtml);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            current.html(currentHtml);
        }
    });
});

$('.btn-form-contact input').on('click',function(event){

    event.preventDefault();
    var data = new FormData();
    var idForm = $(this).attr('id').replace('_submit','');
    var id = $(this).attr('id').replace('_inbox_submit','');
    var current = $(this);
    var currentHtml = current.html();
    current.html('<i class="fa fa-spinner fa-spin"></i>');
    $.ajax({
        url: BASE_URL + 'ajax/?controller=contact&action=sendForm&lg='+LG_CURRENT+'&uri='+MODULE_URI,
        type: 'POST',
        data: $("#"+idForm).serialize(),
        success: function(response, textStatus, jqXHR) {
            var rep = JSON.parse(response);
            current.attr("disabled", "disabled");
            if (rep.code == '200') {
                $('#'+idForm).append('<div class="alert alert-success text-center">'+rep.data+'</div>');
                window.setTimeout(function(){
                    location.reload();
                },5000);
            } else {
                $.each(rep.data,function(k,v){
                    $('#'+idForm + ' #'+k).addClass('i-error');
                    if (k == 'result_captcha') {
                        $('#'+idForm + ' #captcha_result').addClass('i-error');
                    }
                });
                current.removeAttr("disabled");
            }

            $('.i-error').on('click focus',function(){
                $(this).removeClass('i-error');
            });
            current.html(currentHtml);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            current.html(currentHtml);
        }
    });
});

$('.btn-form-comment input').on('click',function(event){

    event.preventDefault();
    var data = new FormData();
    var idForm = $(this).attr('id').replace('_submit','');
    var id = $(this).attr('id').replace('_comment_submit','');
    var current = $(this);
    var currentHtml = current.html();
    current.html('<i class="fa fa-spinner fa-spin"></i>');
    $.ajax({
        url: BASE_URL + 'ajax/?controller=comment&action=sendForm&lg='+LG_CURRENT+'&uri_module='+MODULE_URI+'&uri_content='+CONTENT_URI,
        type: 'POST',
        data: $("#"+idForm).serialize(),
        success: function(response, textStatus, jqXHR) {
            var rep = JSON.parse(response);
            current.attr("disabled", "disabled");
            if (rep.code == '200') {
                $('#'+idForm).append('<div class="alert alert-success text-center">'+rep.data+'</div>');
                window.setTimeout(function(){
                    location.reload();
                },5000);
            } else {
                $.each(rep.data,function(k,v){
                    $('#'+idForm + ' #'+k).addClass('i-error');
                    if (k == 'result_captcha') {
                        $('#'+idForm + ' #captcha_result').addClass('i-error');
                    }
                });
                current.removeAttr("disabled");
            }

            $('.i-error').on('click focus',function(){
                $(this).removeClass('i-error');
            });
            current.html(currentHtml);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            current.html(currentHtml);
        }
    });
});

$('.nav a').on('click', function(){
    if ($(window).width() < 769) {
        $('.btn-navbar').click();
        $('.navbar-toggle').click()     
    }

});

$("#nav ul li a[href^='#']").on('click', function(e) {

   // prevent default anchor click behavior
   e.preventDefault();

   // store hash
   var hash = this.hash;

   // animate
   $('html, body').animate({
       scrollTop: $(hash).offset().top
     }, 300, function(){

       // when done, add hash to url
       // (default click behaviour)
       window.location.hash = hash;
     });

});

// Add to Cart
$('.addCart').on('click',function(event){
    event.preventDefault();
    var current = $(this);
    var currentHtml = current.html();
    current.html('<i class="fa fa-spinner fa-spin"></i>');
    var qty = $('input.input-qty-checkout').val();
    $.get($(this).attr('href') + "&qty=" + qty,{},function(data){
        if (data.code == 200) {

            var newElement= $('#img-shop-content').eq(0).clone();
            newElement.css({
                "position":"absolute", 
                "max-width": "600px",
                "padding": "0",
                "border-solid": "0",
                "z-index": "999999",
                "top": $("#img-shop-content").offset().top + "px",
                "left": ($("#img-shop-content").offset().left + 250) + "px",
            });

            //Now animate
            newElement
                .appendTo("body")
                .animate({
                    'top': $(".cartWithCount").offset().top + "px",
                    'left': $(".cartWithCount").offset().left + "px",
                    'width': '0px',
                    }, 
                    500,
                    'swing',
                    function(){
                        newElement.remove();
                    }
                );
            
            $('.cartWithCount').html('<span class="badge">'+data.data.count+'</span>');
            var countAlert = $('.uidAlert').length;
            var uidAlert = countAlert + 1;
            var message = '<div class="alert alert-success uidAlert uidAlert-'+uidAlert+'"><i class="fa fa-check fa-lg "></i> ' +data.data.message+'</div>';
            $('.notification-alert-box').append(message);
            $('.uidAlert-'+uidAlert).hide();
            $('.uidAlert-'+uidAlert).fadeIn();
            window.setTimeout(function(){
                $('.uidAlert-'+uidAlert).fadeOut();
            },3000);
        }
        current.html(currentHtml);
    },'json');
    return false;
});

$('body').on('click','.click-cart-plus',function(event) {
    var counter = $('input.input-qty-checkout').val();
    if (isNaN(counter)) {
        counter = 1;
    }
    counter++;
    $('input.input-qty-checkout').val(counter);
});
$('body').on('click','.click-cart-minus',function(event) {
    var counter = $('input.input-qty-checkout').val();
    if (isNaN(counter) || counter < 1 || counter === 0) {
        counter = 1;
    }
    counter--
    $('input.input-qty-checkout').val(counter);
});
// Rating 
$('.rating').rating({
  extendSymbol: function () {
    var title;
    $(this).on('rating.rateenter', function (e, rate) {
      title = rate;
      $('.int-stars').html(rate);
      console.log(rate);
      if (rate > 1) {
        $('.int-stars-one').hide();
        $('.int-stars-more').show();
      } else {
        $('.int-stars-one').show();
        $('.int-stars-more').hide();
      }
      $('#doorgets_comment_stars').val(rate);
    })
    .on('rating.rateleave', function () {

    });
  }
});

// Comment
window.setTimeout(function(){
    $('.doorGets-comment .alert-success').hide();
},5000);




$('#flash').slideDown('slow');
setTimeout(function() {
    $('#flash').slideUp('slow');
}, 5000);

$('#closeFlash').click(function() {

    $('#flash').slideUp('slow');
});

$('div[class*=btn-front-edit-]').parent('div').each(function(index, el) {
    $(el).css('z-index','9999');
    // $(el).css('position','absolute');
    // $(el).css('right','22px');
    $(this).parent('div').css('border','none');
    $(this).css('border','none');
});


