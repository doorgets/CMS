$().ready(function() {
    
    function doClickPlus(){
        $(".btn-plus").click(function(){
            $(this).hide();
            $(this).next('.box-moins').fadeIn();
        });
        $(".btn-moins").click(function(){
            $(this).parent().prev(".btn-plus").show();
            $(this).parent('.box-moins').hide();
        });        
    }
    doClickPlus()
    $('#flash').slideDown('slow');
    setTimeout(function() {
        $('#flash').slideUp('slow');
    }, 5000);
    
    $('#closeFlash').click(function(){
    
        $('#flash').slideUp('slow');
    });
    
    var boxes = $('input[type=checkbox]:checked');
    $(boxes).next('span').attr('class','in-check-ok');
    
    $( "input[type=checkbox]" ).on( "click", function(){
        if($(this).is(':checked')){
            $(this).next('span').attr('class','in-check-ok');
        }else{
            $(this).next('span').attr('class','in-check');
        }
    });
    
    $( ".datepicker-from" ).datepicker({
        
        maxDate: '0',
        dateFormat : "dd-mm-yy",
        defaultDate: "+1w",
        changeMonth: true,
        changeYear: true,
        onClose: function( selectedDate ) {
            $( ".datepicker-to" ).datepicker( "option", "minDate", selectedDate );
        }
    });
    
    
    $( ".datepicker-to" ).datepicker({
        defaultDate: "+1w",
        dateFormat : "dd-mm-yy",
        changeMonth: true,
        changeYear: true,
        maxDate: '0',
        onClose: function( selectedDate ) {
            $( ".datepicker-from" ).datepicker( "option", "maxDate", selectedDate );
        }
        
    });
    
    $('#go-to-racc select').change(function(){
        if($(this).val() != ''){
            $(location).attr('href',$(this).val());
        }
        
    });
    
    function doSortable(){
        var ii = 1;
        $( "#sortable li" ).each(function() {
            
            $( this  ).find('.input-label').attr( "name", "input-label-" + ii);
            $( this  ).find('.input-info').attr( "name", "input-info-" + ii);
            $( this  ).find('.input-css').attr( "name", "input-css-" + ii);
            $( this  ).find('.input-obligatoire').attr( "name", "input-obligatoire-" + ii);
            $( this  ).find('.input-liste').attr( "name", "input-liste-" + ii);
            $( this  ).find('.input-filter').attr( "name", "input-filter-" + ii);
            $( this  ).find('.input-type').attr( "name", "input-type-" + ii);
            $( this  ).find('.input-active').attr( "name", "input-active-" + ii);
            $( this  ).find('.input-value').attr( "name", "input-value-" + ii);
            $( this  ).find('.input-value').attr( "value", "field-" + ii);
            
            $( this  ).find('.input-zip').attr( "name", "input-zip-" + ii);
            $( this  ).find('.input-png').attr( "name", "input-png-" + ii);
            $( this  ).find('.input-jpg').attr( "name", "input-jpg-" + ii);
            $( this  ).find('.input-gif').attr( "name", "input-gif-" + ii);
            $( this  ).find('.input-pdf').attr( "name", "input-pdf-" + ii);
            $( this  ).find('.input-swf').attr( "name", "input-swf-" + ii);
            $( this  ).find('.input-doc').attr( "name", "input-doc-" + ii);
            
            ii++;
        
        }); 
    }
    
    function doSortableEdit(){
        var ii = 1;
        $( "#editsortable li" ).each(function() {
            
            $( this  ).find('.input-label').attr( "name", "input-label-" + ii);
            $( this  ).find('.input-info').attr( "name", "input-info-" + ii);
            $( this  ).find('.input-css').attr( "name", "input-css-" + ii);
            $( this  ).find('.input-obligatoire').attr( "name", "input-obligatoire-" + ii);
            $( this  ).find('.input-liste').attr( "name", "input-liste-" + ii);
            $( this  ).find('.input-filter').attr( "name", "input-filter-" + ii);
            $( this  ).find('.input-type').attr( "name", "input-type-" + ii);
            $( this  ).find('.input-value').attr( "name", "input-value-" + ii);
            $( this  ).find('.input-active').attr( "name", "input-active-" + ii);
            
            $( this  ).find('.input-zip').attr( "name", "input-zip-" + ii);
            $( this  ).find('.input-png').attr( "name", "input-png-" + ii);
            $( this  ).find('.input-jpg').attr( "name", "input-jpg-" + ii);
            $( this  ).find('.input-gif').attr( "name", "input-gif-" + ii);
            $( this  ).find('.input-pdf').attr( "name", "input-pdf-" + ii);
            $( this  ).find('.input-swf').attr( "name", "input-swf-" + ii);
            $( this  ).find('.input-doc').attr( "name", "input-doc-" + ii);
            
            ii++;
        
        }); 
    }
    
    $( "#sortable" ).sortable({
        revert: true,
    });
    $( "#editsortable" ).sortable({
        revert: true,
    });
    
    $( ".draggable" ).draggable({
        connectToSortable: "#sortable",
        helper: "clone",
        revert: "invalid",
        stop:   function( event, ui ) {
                    $(ui.helper).addClass("is-online");
                    $( "#sortable li div.hid" ).show();
                    $(".close-me").click(function(){
                        parent_li = $(this).closest('li');
                        parent_li.fadeOut('slow', function() {$(this).remove();});
                    });
                    doClickPlus()
                }
        
    });
    
    $( "ul, li" ).disableSelection();
    
    doSortable();
    $( "#sortable" ).mouseout(function(){ doSortable(); });
    doSortableEdit();
    $( "#editsortable" ).mouseout(function(){ doSortableEdit(); });
    
    $(".close-me").click(function(){
        parent_li = $(this).closest('li');
        parent_li.fadeOut('slow', function() {$(this).remove();});
    });
    
    // ----------------------
    $(".nav-off").click(function(){
    var pos = $('.p-left').width();
    if(pos === 250){
      
        $('.p-left-top img').hide();
        $('.nav-off').css('width','50px');
        $('.nav-off .nav-off-c').css('width','40px');
        $('.nav-off .nav-off-c').css('top','0');
        $('.nav-off .nav-off-c').html('&#8594;');
        $('.p-left-bottom ul li span').hide();
        
          $('.p-left').animate({ width: "-=200" }, 100, function() {
              var wcontent = $( window ).width() - $('.p-left').width();
              var wcontents = wcontent + "px";
              $('.p-content').width(wcontents);    
          });
          
        $('.p-content').animate({ left: "-=200" }, 100, function() { });
        $('.params-out').animate({ left: "-=200", width: "+=200" }, 100, function() { });
        
        
      }else{
        
        $('.nav-off').css('width','250px');
        $('.nav-off .nav-off-c').css('width','240px');
        $('.nav-off .nav-off-c').html('&#8592;');
        
          $('.p-left').animate({ width: "+=200"}, 100, function() {
          
              $('.p-left-bottom ul li span').fadeIn();
              var wcontent = $( window ).width() - $('.p-left').width() ;
              var wcontents = wcontent + "px";
              $('.p-content').width(wcontents);
              
          });
          
        $('.p-content').animate({ left: "+=200" }, 100, function() { });
        $('.params-out').animate({ left: "+=200", width: "-=200"  }, 100, function() { });
        $('.p-left-top img').fadeIn();
        
        
        
      }
      
    });
    
    $('.tools-bt').click(function(){
      
      if($('.params-out').is(':hidden')){
        
          $('.params-out').animate({ left: "+=251" }, 100, function() {
              
              var wcontent = $( window ).width() - $('.p-left').width() - 252;
              var wcontents = wcontent + "px";
              $('.p-content').width(wcontents);    
          });
          
          $('.params-out').fadeIn();
          $('.p-content').animate({ left: "+=251" }, 100, function() { });
          $(this).css({"background":"#373737","color":"#ffffff"});
          
      }else{
        
          $('.params-out').animate({ left: "-=251" }, 100, function() {
              var wcontent = $( window ).width() - $('.p-left').width();
              var wcontents = wcontent + "px";
              $('.p-content').width(wcontents); 
          });
          
          $('.p-content').animate({ left: "-=251" }, 100, function() { });
          $('.params-out').fadeOut();
          $(this).css({"background-color":"#EDEDED","color":"#555"});
        
      }
      
      
    });
    
    var isHiddenOut = 252;
    if($('.params-out').is(':hidden')){ isHiddenOut = 0; }
    
    var wcontent = $( window ).width() - $('.p-left').width() - isHiddenOut;
    var wcontents = wcontent + "px";
    $('.p-content').width(wcontents);
    
    $( window ).resize(function() {
      
      var wcontent = $( window ).width() - $('.p-left').width() - isHiddenOut;
      var wcontents = wcontent + "px";
      $('.p-content').width(wcontents);
      
    });
    // ----------------------
    
    $( "#tabs" ).tabs();
    
    // ----------------------
    
    $("#modules_addblog_nom").keyup(function(){

        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addblog_uri").val(str);        
    });
    $("#modules_addblog_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addblog_meta_titre").val(str);
        
    });
    $("#modules_addblog_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addblog_meta_description").val(str);
        
    });
    
    // --------------------------
    
    $("#modules_addmultipage_nom").keyup(function(){

        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addmultipage_uri").val(str);        
    });
    $("#modules_addmultipage_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addmultipage_meta_titre").val(str);
        
    });
    $("#modules_addmultipage_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addmultipage_meta_description").val(str);
        
    });
    
    // ----------------------
    
    $("#modules_addpage_nom").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addpage_uri").val(str);        
    });
    $("#modules_addpage_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addpage_meta_titre").val(str);
        
    });
    $("#modules_addpage_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addpage_meta_description").val(str);
        
    });
    
    // ----------------------
    $("#modules_addpartner_nom").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addpartner_uri").val(str);        
    });
    $("#modules_addpartner_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addpartner_meta_titre").val(str);
        
    });
    $("#modules_addpartner_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addpartner_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addinbox_nom").keyup(function(){

        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addinbox_uri").val(str);        
    });
    $("#modules_addinbox_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addinbox_meta_titre").val(str);
        
    });
    $("#modules_addinbox_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addinbox_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addapplicationjob_nom").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addapplicationjob_uri").val(str);        
    });
    $("#modules_addapplicationjob_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addapplicationjob_meta_titre").val(str);
        
    });
    $("#modules_addapplicationjob_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addapplicationjob_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addnews_nom").keyup(function(){

        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addnews_uri").val(str);        
    });
    $("#modules_addnews_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addnews_meta_titre").val(str);
        
    });
    $("#modules_addnews_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addnews_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addvideo_nom").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addvideo_uri").val(str);        
    });
    $("#modules_addvideo_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addvideo_meta_titre").val(str);
        
    });
    $("#modules_addvideo_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addvideo_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addimage_nom").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addimage_uri").val(str);        
    });
    $("#modules_addimage_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addimage_meta_titre").val(str);
        
    });
    $("#modules_addimage_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addimage_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addfaq_nom").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addfaq_uri").val(str);        
    });
    $("#modules_addfaq_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modules_addfaq_meta_titre").val(str);
        
    });
    $("#modules_addfaq_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modules_addfaq_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addblock_titre").keyup(function(){

        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addblock_uri").val(str);        
    });
    // ----------------------
    $("#modules_addlink_nom").keyup(function(){

        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addlink_uri").val(str);        
    });
    // ----------------------
    $("#modulecategory_add_nom").keyup(function(){
    
        var str = $(this).val();
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
      
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc------";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
      
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '-') // collapse whitespace and replace by -
          .replace(/-+/g, '-'); // collapse dashes
          
        $("#modulecategory_add_uri").val(str);        
    });
    $("#modulecategory_add_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modulecategory_add_meta_titre").val(str);
        
    });
    $("#modulecategory_add_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modulecategory_add_meta_description").val(str);
        
    });
    // ----------------------
    $("#modulecategory_edit_titre").keyup(function(){
    
        var str = $(this).val();
        $("#modulecategory_edit_meta_titre").val(str);
        
    });
    $("#modulecategory_edit_description").keyup(function(){
    
        var str = $(this).val();
        var lendesc =  str.length;
        if(lendesc >= 250){
            str = str.substr(0,250);
        }
        $("#modulecategory_edit_meta_description").val(str);
        
    });
    // ----------------------
    $("#modules_addgenform_titre").keyup(function(){
    
        var str = $(this).val();
        
        str = str.replace(/^\s+|\s+$/g, ''); // trim
        str = str.toLowerCase();
        
        // remove accents, swap ñ for n, etc
        var from = "ãàáäâẽèéëêìíïîõòóöôùúüûñç·/_,:;";
        var to   = "aaaaaeeeeeiiiiooooouuuunc      ";
        for (var i=0, l=from.length ; i<l ; i++) {
          str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
        }
        
        str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
          .replace(/\s+/g, '') // collapse whitespace and replace by -
          .replace(/-+/g, ''); // collapse dashes
          
        $("#modules_addgenform_uri").val(str);        
    });
    // ----------------------
    // ----------------------
    // ----------------------
    // ----------------------
    // ----------------------
    

    // ----------------------
    var collection = $(".tinymce");
    collection.each(function() {
        
        var textarea = $(this);
        var txt = textarea.val();
        textarea.val(txt.replace(/<\s\?/gi, "\&lt;?"));
        var txt2 = textarea.val();
        textarea.val(txt2.replace(/\?\s\&gt;/gi, "?\&gt;"));
        
        
    });
    
    $("#doorGets_search_filter_q_date_creation_start").parent('.input-group').css('width','100px');
    $("#doorGets_search_filter_q_date_creation_end").parent('.input-group').css('width','100px');
    $("#doorGets_search_filter_q_date_creation_start").parent('.input-group').css('display','inline-block');
    $("#doorGets_search_filter_q_date_creation_end").parent('.input-group').css('display','inline-block');
});
