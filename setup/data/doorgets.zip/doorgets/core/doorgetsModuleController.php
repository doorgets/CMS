<?php

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorgets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


class doorgetsModuleController extends doorgetsController{
    
    
    public function __construct( $Name,$doorGetsController){
        
        
        parent::__construct($doorGetsController);
        
        $this->controllerName   = $Name;
        $params                 = $doorGetsController->Params();
        $lgActuel               = $doorGetsController->getLangueTradution();
        $redirectUrlModule      = './?controller=modules&lg='.$lgActuel;
        $moduleInfos            = $doorGetsController->moduleInfos($this->uri,$lgActuel);
        $redirectUrl            = './?controller=module'.$moduleInfos['type'].'&uri='.$this->uri.'&lg='.$lgActuel;
        
        
        // If isn't valid uri do rediction to modules controller
        if(
            !array_key_exists('uri',$params['GET'])
            || empty($params['GET']['uri']) || empty($this->uri)
            
        ){
            
            FlashInfo::set($this->l("L'URI n'existe pas"),"error");
            header('Location:'.$redirectUrlModule);
            exit();
            
        }
        
        if( 'module'.$moduleInfos['type'] !== $this->controllerName )
        {
            
            FlashInfo::set($this->l("Erreur"),"error");
            header('Location:'.$redirectUrl.'#'.$moduleInfos['type'].'-'.$this->controllerName);
            exit();
            
        }
        
        // check for category id
        if(array_key_exists('categorie',$params['GET']))
        {
            
            $idCategorie = $params['GET']['categorie'];
            $doorGetsController->loadCategories($this->uri);
            $allCategories = $doorGetsController->categorieSimple;
            unset($allCategories[0]);
            if(!is_numeric($idCategorie)){ $idCategorie = '-!-'; }
            if(!is_numeric($idCategorie) || !array_key_exists($idCategorie,$allCategories))
            {
                
                FlashInfo::set($this->l("La catégorie '$idCategorie' n'existe pas"),"error");
                header('Location:'.$redirectUrl);
                exit();
                
            }
            
        }
        
        // get Content for edit / delete
        if(array_key_exists('id',$params['GET']))
        {
            
            $id = $params['GET']['id'];
            $isContent = $doorGetsController->dbQS($id,$this->table);
            if(!is_numeric($id)){ $id = '-!-'; }
            if(empty($isContent)){
                
                FlashInfo::set($this->l("Le contenu '$id' n'existe pas"),"error");
                header('Location:'.$redirectUrl);
                exit();
                
            }
            
        }
        
    }
    
    public function indexAction(){
        
        $this->form['_search']          = new Formulaire('doorGets_search');
        $this->form['_position_down']   = new Formulaire('_position_down');
        $this->form['_position_up']     = new Formulaire('_position_up');
        $this->form['_massdelete']      = new Formulaire($this->controllerName.'_massdelete');
        
        $this->form['_search_filter']   = new Formulaire('doorGets_search_filter');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function addAction(){
        
        $this->form = new Formulaire($this->controllerName.'_add');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function editAction(){
        
        $this->form = new Formulaire($this->controllerName.'_edit');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function deleteAction(){
        
        $this->form = new Formulaire($this->controllerName.'_delete');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
    public function massdeleteAction(){
        
        $this->form['massdelete_index'] = new Formulaire($this->controllerName.'_massdelete');
        
        // Generate the model
        $this->getModel();
        
        // return the view
        return $this->getView();
    
    }
    
}