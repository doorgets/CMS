<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-title-breadcrumb page-header">
        <ol class="breadcrumb">
            <li><a href="./?controller=configuration">{{!$this->l('Configuration')!}}</a></li>
            <li class="active">{{!$this->l('Logo')!}} & {{!$this->l('Icône')!}}</li>
        </ol>
    </div>
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <h2>
                <b class="glyphicon glyphicon-picture"></b> {{!$this->l('Logo')!}} & {{!$this->l('Icône')!}}
                <small>{{!$this->l("Modifier le logo et l'icône de votre site")!}}.</small>
            </h2>
        </div>
        
        {{!$this->Controller->form['configuration_media_logo']->open('post')!}}
        <b>{{!$this->l('Choisir une image pour votre logo').' :</b> '.$this->l('Format .PNG seulement')!}}
        <div class="doorGets-configuration-box-media">
            <div class="separateur-tb"></div>
            <img src="{{!BASE_IMG.'logo.png'!}}" class="doorGets-img-ico" >
            <div class="separateur-tb"></div>
            {{!$this->Controller->form['configuration_media_logo']->file('','img_logo')!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form['configuration_media_logo']->submit($this->l('Sauvegarder'))!}}
        </div>
        {{!$this->Controller->form['configuration_media_logo']->close()!}}
        
        <div class="separateur-tb"></div>
        <div class="separateur-tb"></div>
        
       {{!$this->Controller->form['configuration_media_icone']->open('post')!}}
       <b>{{!$this->l('Choisir une image pour votre icône').' :</b> '.$this->l('Format .ICO seulement')!}}
        <div class="doorGets-configuration-box-media">
            <div class="separateur-tb"></div>
            <img src="{{!URL.'favicon.ico'!}}" class="doorGets-img-ico" >
            <div class="separateur-tb"></div>
            {{!$this->Controller->form['configuration_media_logo']->file('','icone_logo')!}}
            <div class="separateur-tb"></div>
            {{!$this->Controller->form['configuration_media_icone']->submit($this->l('Sauvegarder'))!}}
        </div>
        
        {{!$this->Controller->form['configuration_media_icone']->close()!}}
        
    </div>
</div>