<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


?>
<div class="doorGets-rubrique-center">
    <div class="doorGets-rubrique-center-content">
        <div class="doorGets-rubrique-left-center-title page-header">
            <span class="create" ><a class="doorGets-comebackform" href="?controller=theme"><img src="{{!BASE_IMG!}}retour.png" class="retour-img"> {{!$this->l('retour')!}}</a></span>
            <h2>
                <img src="{{!BASE_IMG!}}icone_theme.png" > <a href="?controller=theme">{{!$this->l('Thème')!}} </a> 
                <small>{{!$this->l('Configurer le thème de votre site')!}}.</small>
            </h2>
        </div>
        <legend>{{!$this->l('Modifier un thème')!}} : {{!$theme!}} {{?($nameTheme === $theme):}}<div class="right-theme-title "><img src="{{!BASE_IMG.'activer.png'!}}"  /> <small>{{!$this->l('Thème par défaut')!}}</small></div>{?}</legend>
        <div class="row">
            <div class="col-md-2">
                {{?(array_key_exists('css',$themeListe)):}}
                    <div class="list-group">
                        <div class="list-group-item"><h3>CSS</h3></div>
                        {{/($themeListe['css'] as $file):}}
                            <a class="list-group-item {{?($fileSelected === $file):}}active{?}" href="?controller=theme&action=edit&name={{!$theme!}}&file={{!$file!}}">{{!$file!}}</a>
                        {/}
                    </div>
                {?}
                {{?(array_key_exists('js',$themeListe)):}}
                    <div class="list-group">
                        <div class="list-group-item"><h3>JavaScript</h3></div>
                        {{/($themeListe['js'] as $file):}}
                            <a class="list-group-item {{?($fileSelected === $file):}}active{?}" href="?controller=theme&action=edit&name={{!$theme!}}&file={{!$file!}}">{{!$file!}}</a>
                        {/}
                    </div>
                {?}
                
                {{?(array_key_exists('tpl',$themeListe)):}}
                    {{asort($themeListe['tpl']);}}
                    <div class="list-group">
                        <div class="list-group-item"><h3>Template</h3></div>
                        {{/($themeListe['tpl'] as $dirFile=>$file):}}
                            <a title="{{!$dirFile!}}" class="list-group-item {{?($fileSelected === $file):}}active{?}" href="?controller=theme&action=edit&name={{!$theme!}}&file={{!$file!}}">{{!$file!}}</a>
                        {/}
                    </div>
                {?}
            </div>
            <div class="col-md-10">
                <div class="u-title"><label>{{!$this->l('Fichier')!}} &#187; {{!$urlFile!}}</label></div>
                {{!$this->Controller->form->open('post','','')!}}
                {{!$this->Controller->form->textarea('','content_nofi',$fileContent)!}}
                <div class="separateur-tb"></div>
                {{!$this->Controller->form->submit($this->l("Sauvegarder"))!}}
                {{!$this->Controller->form->close()!}}
            </div>
        </div>
    </div>
</div>
