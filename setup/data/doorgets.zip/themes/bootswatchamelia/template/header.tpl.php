<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/


 /*
  * Variables :
        $label
        $title
        $description 
        $keywords
 */
 
$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

?><!doctype html>
<html lang="{{!$this->myLanguage()!}}">
    <head>
        <title>{{!$label!}}</title>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
        <meta name="generator" content="doorGets" />
        <meta name="author" content="Doorgets.com, doorgets" />
        <meta name="description" content="{{!$description!}}" />
        <meta name="keywords" content="{{!$keywords!}}" />
        
        <meta property="og:site_name" content="{{!$title!}}" />
        <meta property="og:title" content="{{!$label!}}" />
        <meta property="og:url" content="{{!$url!}}" />
        <meta property="og:language" content="{{!$this->myLanguage()!}}" />
        
        {{!$rssLinks!}}
	
        <link href="{{!URL!}}skin/bootstrap/css/bootstrapamelia.min.css" rel="stylesheet" type="text/css" />
        <link href="{{!URL!}}themes/{{!$this->theme!}}/css/doorgets.css" rel="stylesheet" type="text/css" />
	
    </head>
    <body>
    <div id="fb-root"></div>
    <script type="text/javascript">(function(d, s, id) {   var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)){ return; } js = d.createElement(s);  js.id = id;js.src = "//connect.facebook.net/{{!$lgFacebook!}}/all.js#xfbml=1&version=v2.0&status=0&appId=269175359761218"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script>