<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
  *
        $isContents

 */
 
 $i = 1;
 $iC = count($isContents);
?>
<!-- doorGets:start:modules/partner/partner_listing -->
<div class="doorGets-partner-listing doorGets-module-{{!$Website->getModule()!}}">
    
    {{?(!empty($isContents)):}}
    
        <div>
            <div class="page-header">
                <p>
                    <h2>{{!$Website->l('Nos Partenaires')!}}</h2>
                </p>
            </div>
            <ul>
            {{/($isContents as $content):}}
            <div class="row list-partner {{?($i===$iC):}}list-partner-last{?} ">
                <div class="col-sm-6 col-md-4">
                    <div class="thumbnail">
                        <img src="{{!BASE_DATA.$Website->getModule().'/'.$content['image']!}}" alt="...">
                        <div class="caption">
                            <h3>{{!$content['titre']!}}</h3>
                            <p>{{!$content['description']!}}</p>
                            <p><b class="glyphicon glyphicon-share-alt"></b> <a href="{{!$content['url']!}}" title="{{!$content['url']!}}" target="blank" >{{!$content['url']!}} </a></p>
                        </div>
                    </div>
                </div>
            </div>
                
            {{$i++;}}
            {/}
            </ul>
        </div>
        
    {?}
</div>
<!-- doorGets:end:modules/partner/partner_listing -->