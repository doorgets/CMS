<?php if( !defined(DOORGETS) ){ header('Location:../'); exit(); }

/*******************************************************************************
/*******************************************************************************
    doorGets 6.0 - 20, February 2014
    doorGets it's free PHP Open Source CMS PHP & MySQL
    Copyright (C) 2012 - 2014 By Mounir R'Quiba -> Crazy PHP Lover
    
/*******************************************************************************

    Website : http://www.doorgets.com
    Contact : http://www.doorgets.com/?contact
    
/*******************************************************************************
    -= One life, One code =-
/*******************************************************************************
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
******************************************************************************
******************************************************************************/

 
 /*
  * Variables :
  *
        $title
        $description
        $article
        $date_creation
 */
 
?>
<!-- doorGets:start:modules/inbox/inbox_form -->
<div class="doorGets-contact-content doorGets-module-{{!$Website->getModule()!}}">
    <div class="jumbotron">
        <p>
            <h2>{{!$Website->l('Contactez-nous')!}}</h2>
            <p>{{!$Website->l('Veuilliez remplir le fomulaire suivant afin de nous contacter, nous vous contacterons rapidement...');}}</p>
            
        </p>
    </div>
    {{?($Website->form['contact_inbox']->isSended):}}
        <div class="alert alert-success">
            {{!$Website->l("Votre message à été envoyé")!}}, {{!$Website->l("nous prendrons contact avec vous rapidement")!}}, {{!$Website->l("merci")!}}.
        </div>
        {{ $_POST = array(); }}
        
    {?}
    {{!$Website->form['contact_inbox']->open('post','','')!}}
        {{!$Website->form['contact_inbox']->input('','secureFormulaire','hidden',$_SESSION['idForm'])!}}
        <div class="input-group">
            {{!$Website->form['contact_inbox']->input('<span class="color-red">*</span> '.$Website->l('Nom / Entreprise').'<br />','nom','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_inbox']->input($Website->l('Téléphone').'<br />','telephone','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_inbox']->input('<span class="color-red">*</span> '.$Website->l('E-mail pour vous répondre').'<br />','email','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_inbox']->input('<span class="color-red">*</span> '.$Website->l('Sujet').'<br />','sujet','text','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_inbox']->textarea('<span class="color-red">*</span> '.$Website->l('Message').'<br />','message','','form-control')!}}
        </div>
        <div class="input-group">
            {{!$Website->form['contact_inbox']->submit($Website->l('Envoyer le message'),'','btn btn-success')!}}
            <div class="right"><span class="color-red">*</span> {{!$Website->l('Champ obligatoire')!}}</div>
        </div>
        
    {{!$Website->form['contact_inbox']->close()!}}
    
</div>
<!-- doorGets:end:modules/inbox/inbox_form -->