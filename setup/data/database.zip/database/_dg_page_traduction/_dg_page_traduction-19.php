a:12:{s:2:"id";s:2:"19";s:10:"id_content";s:1:"2";s:6:"langue";s:2:"su";s:5:"titre";s:7:"Sitemap";s:11:"description";s:7:"Sitemap";s:15:"article_tinymce";s:325:"&lt;div class=&quot;container&quot;&gt;
&lt;div class=&quot;row&quot;&gt;
&lt;div class=&quot;col-md-12&quot;&gt;
&lt;div class=&quot;content-bloc&quot;&gt;
&lt;h2&gt;Sitemap&lt;/h2&gt;
&lt;p&gt;{{!getHtmlSitemap!}}&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;hr class=&quot;soften&quot; /&gt;";s:3:"uri";N;s:10:"uri_module";s:7:"sitemap";s:10:"meta_titre";s:7:"Sitemap";s:16:"meta_description";s:7:"Sitemap";s:9:"meta_keys";s:7:"Sitemap";s:17:"date_modification";s:10:"1393273285";}